# frozen_string_literal: true

class Publisher::SessionsController < ApplicationController
end
