module LazyLoadTestModule
  def lazy_loading_works?
    "yes it does"
  end
end