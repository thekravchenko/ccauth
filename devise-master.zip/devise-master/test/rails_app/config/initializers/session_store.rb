# frozen_string_literal: true

RailsApp::Application.config.session_store :cookie_store, key: '_rails_app_session'
