# frozen_string_literal: true

module Devise
  VERSION = "4.8.0".freeze
end
